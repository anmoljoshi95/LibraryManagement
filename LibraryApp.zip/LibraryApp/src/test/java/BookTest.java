import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class BookTest {

    private Book book;

    @Before
    public void setUp() {
        book = new Book("The Great Gatsby", "F. Scott Fitzgerald", "1234567890", "Classic", 1925, true);
    }

    @Test
    public void testGetTitle() {
        assertEquals("The Great Gatsby", book.getTitle());
    }

    @Test
    public void testSetTitle() {
        book.setTitle("New Title");
        assertEquals("New Title", book.getTitle());
    }

    @Test
    public void testGetAuthor() {
        assertEquals("F. Scott Fitzgerald", book.getAuthor());
    }

    @Test
    public void testSetAuthor() {
        book.setAuthor("New Author");
        assertEquals("New Author", book.getAuthor());
    }

    @Test
    public void testGetISBN() {
        assertEquals("1234567890", book.getISBN());
    }

    @Test
    public void testSetISBN() {
        book.setISBN("0987654321");
        assertEquals("0987654321", book.getISBN());
    }

    @Test
    public void testGetGenre() {
        assertEquals("Classic", book.getGenre());
    }

    @Test
    public void testSetGenre() {
        book.setGenre("New Genre");
        assertEquals("New Genre", book.getGenre());
    }

    @Test
    public void testGetPublishYear() {
        assertEquals(1925, book.getPublishYear());
    }

    @Test
    public void testSetPublishYear() {
        book.setPublishYear(2021);
        assertEquals(2021, book.getPublishYear());
    }

    @Test
    public void testIsAvailable() {
        assertTrue(book.isAvailable());
    }

    @Test
    public void testSetAvailable() {
        book.setAvailable(false);
        assertFalse(book.isAvailable());
    }
}
