import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashMap;

public class LibraryTest {

    private Library library;
    private Book book1;
    private Book book2;

    @BeforeEach
    public void setUp() {
        library = new Library();
        book1 = new Book("123", "Author1", "Title1","Horror" ,2019,true);
        book2 = new Book("456", "Author2", "Title2","comedy",2015, false);
    }

    @Test
    public void testAddBook() {
        assertEquals(MESSAGECODES.BookAdded, library.addBook(book1));
        assertEquals(MESSAGECODES.BookExist, library.addBook(book1));
    }

    @Test
    public void testRemoveBook() {
        library.addBook(book1);
        assertEquals(MESSAGECODES.BookRemoved, library.removeBook("123"));
        assertEquals(MESSAGECODES.BookNotFound, library.removeBook("123"));
    }

    @Test
    public void testFindBookByAuthor() {
        library.addBook(book1);
        library.addBook(book2);

        ArrayList<Book> foundBooks = library.findBookByAuthor("Author1");
        assertEquals(1, foundBooks.size());
        assertEquals(book1, foundBooks.get(0));

        foundBooks = library.findBookByAuthor("UnknownAuthor");
        assertEquals(0, foundBooks.size());
    }

    @Test
    public void testFindBookByTitle() {
        library.addBook(book1);
        library.addBook(book2);

        ArrayList<Book> foundBooks = library.findBookByTitle("Title1");
        assertEquals(1, foundBooks.size());
        assertEquals(book1, foundBooks.get(0));

        foundBooks = library.findBookByTitle("UnknownTitle");
        assertEquals(0, foundBooks.size());
    }

    @Test
    public void testListAllBooks() {
        library.addBook(book1);
        library.addBook(book2);
        ArrayList<Book> allBooks = library.listAllBooks();
        assertEquals(2, allBooks.size());
        assertTrue(allBooks.contains(book1));
        assertTrue(allBooks.contains(book2));
    }

    @Test
    public void testListAvailableBooks() {
        library.addBook(book1);
        library.addBook(book2);

        ArrayList<Book> availableBooks = library.listAvailableBooks();
        assertEquals(1, availableBooks.size());
        assertTrue(availableBooks.contains(book1));
        assertFalse(availableBooks.contains(book2));
    }
}
