

public class Book {

    private String title;
    private String author;
    private String  ISBN;
    private String genre;
    private int publishYear;
    private boolean available;

    public Book(String title, String author, String ISBN, String genre, int publishYear, boolean available) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.genre = genre;
        this.publishYear = publishYear;
        this.available = available;
    }

    // Getter for ISBN
    public String getISBN() {
        return ISBN;
    }

    // Setter for ISBN
    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    // Getter for publishYear
    public int getPublishYear() {
        return publishYear;
    }

    // Setter for publishYear
    public void setPublishYear(int publishYear) {
        this.publishYear = publishYear;
    }

    // Getter for title
    public String getTitle() {
        return title;
    }

    // Setter for title
    public void setTitle(String title) {
        this.title = title;
    }

    // Getter for author
    public String getAuthor() {
        return author;
    }

    // Setter for author
    public void setAuthor(String author) {
        this.author = author;
    }

    // Getter for genre
    public String getGenre() {
        return genre;
    }

    // Setter for genre
    public void setGenre(String genre) {
        this.genre = genre;
    }

    // Getter for available
    public boolean isAvailable() {
        return available;
    }

    // Setter for available
    public void setAvailable(boolean available) {
        this.available = available;
    }
}
