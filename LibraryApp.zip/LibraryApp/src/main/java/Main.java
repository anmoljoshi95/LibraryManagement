

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Book bk = new Book("456", "Author2", "Title2","comedy",2015, false);
        Library lib = new Library();
        System.out.println(lib.addBook(bk));
        System.out.println(lib.findBookByAuthor("Author1"));

    }
}




