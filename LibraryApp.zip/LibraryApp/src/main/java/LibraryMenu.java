//import org.springframework.beans.factory.annotation.Autowired;
//
//
//import java.util.Scanner;
//
//public class LibraryMenu {
//    @Autowired
//    private Library lib;
//
//    Scanner scanner = new Scanner(System.in);
//    public MESSAGECODES add( String command){
//        if(command.equals("add"))
//        {
//
//            System.out.println("Write The Title of Book");
//            String title = scanner.nextLine();
//            System.out.println("Write The Author of Book");
//            String author = scanner.nextLine();
//            System.out.println("Write The ISBN Number of Book");
//            String ISBN = scanner.nextLine();
//            System.out.println("Write The Genre of Book");
//            String genre = scanner.nextLine();
//            System.out.println("Write The Year of Book");
//            int year = scanner.nextInt();
//            System.out.println("Write The Availability(true/false) of Book");
//            boolean available  = scanner.nextBoolean();
//            Book bk = new Book(title,author,ISBN , genre,year,available);
//            return lib.addBook(bk);
//        }
//
//
//
//    }
//
//}
