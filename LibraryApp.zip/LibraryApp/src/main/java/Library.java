
import java.util.HashMap;
import java.util.ArrayList;


enum MESSAGECODES {
    BookAdded("BOOK ADDED SUCCESSFULLY"),
    BookRemoved("BOOK REMOVED SUCCESSFULLY"),
    BookNotFound("NO SUCH BOOK EXISTS"),
    BookExist("THIS BOOK ALREADY EXISTS");

    private final String displayName;

    // Enum constructor
    MESSAGECODES(String displayName) {

        this.displayName = displayName;
    }
}



public class Library {


    private static final HashMap<String, Book> IsbnVsBook = new HashMap<>();

    public MESSAGECODES addBook(Book bk)
    {
        if (IsbnVsBook.containsKey(bk.getISBN())==true)
        {
            return MESSAGECODES.BookExist;
        }
        IsbnVsBook.put(bk.getISBN() , bk);
        return MESSAGECODES.BookAdded;
    }

    public MESSAGECODES removeBook(String ISBN)
    {
        if(IsbnVsBook.containsKey(ISBN)==false)
        {
            return MESSAGECODES.BookNotFound;
        }
        IsbnVsBook.remove(ISBN);
        return MESSAGECODES.BookRemoved;
    }

    public  ArrayList<Book> findBookByAuthor(String Author)
    {
        ArrayList<Book> found = new ArrayList<>();
        IsbnVsBook.forEach((key, value) -> {
            if(value.getAuthor().equalsIgnoreCase(Author))
            {
                found.add(value);
            }

        });
        return found;
    }

    public ArrayList<Book> findBookByTitle(String title){
        ArrayList<Book> found = new ArrayList<>();
        IsbnVsBook.forEach((key, value) -> {
            if(value.getTitle().equalsIgnoreCase(title))
            {
                found.add(value);
            }

        });
        return found;
    }

    public ArrayList<Book> listAllBooks()
    {
        ArrayList<Book> found = new ArrayList<>();
        IsbnVsBook.forEach((key, value) -> {
            found.add(value);

        });
        return found;
    }

    public ArrayList<Book> listAvailableBooks(){
        ArrayList<Book> found = new ArrayList<>();
        IsbnVsBook.forEach((key, value) -> {
            if(value.isAvailable()==true) {
                found.add(value);
            }
        });
        return found;
    }


}
